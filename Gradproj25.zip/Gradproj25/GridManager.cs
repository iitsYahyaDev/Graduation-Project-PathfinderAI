﻿using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour
{
    public static GridManager Instance;

    [Header("Grid Settings")]
    public int width = 15;
    public int height = 15;
    public float cellSize = 1f;
    public GameObject nodePrefab;

    [Header("Visualization")]
    public Material walkableMaterial;
    public Material obstacleMaterial;
    public Material startMaterial;
    public Material endMaterial;
    public Material pathMaterial;
    public Material visitedMaterial;
    public Material highCostMaterial;
    public Material discoveredMaterial;

    public Node[,] grid;
    private Node startNode;
    private Node endNode;
    private int currentMapType = 0;

    void Awake()
    {
        Instance = this;
        GenerateStrategicMap(0);
    }

    public void GenerateNextStrategicMap()
    {
        currentMapType = (currentMapType + 1) % 6;
        GenerateStrategicMap(currentMapType);
    }

    public void GenerateStrategicMap(int mapType)
    {
        // Clear existing grid
        foreach (Transform child in transform)
        {
            Destroy(child.gameObject);
        }

        grid = new Node[width, height];

        switch (mapType)
        {
            case 0: GenerateBalancedMap(); break;
            case 1: GenerateCostHeavyMap(); break;
            case 2: GenerateMazeMap(); break;
            case 3: GenerateOpenMap(); break;
            case 4: GenerateHeuristicTrapMap(); break;
            case 5: GenerateRandomChaosMap(); break;
        }

        SetStartAndEndNodes();
        Debug.Log($"Generated {GetMapTypeName(mapType)}");
    }

    private void SetStartAndEndNodes()
    {
        // Create guaranteed start and end nodes first
        CreateGuaranteedStartEnd();

        // Find farthest apart walkable nodes for more interesting paths
        List<Node> walkableNodes = GetAllWalkableNodes();

        if (walkableNodes.Count >= 2)
        {
            // Find nodes that are farthest apart
            Node farthestStart = walkableNodes[0];
            Node farthestEnd = walkableNodes[0];
            int maxDistance = 0;

            foreach (Node node1 in walkableNodes)
            {
                foreach (Node node2 in walkableNodes)
                {
                    int dist = GetDistance(node1.x, node1.y, node2.x, node2.y);
                    if (dist > maxDistance)
                    {
                        maxDistance = dist;
                        farthestStart = node1;
                        farthestEnd = node2;
                    }
                }
            }

            startNode = farthestStart;
            endNode = farthestEnd;
        }

        // Ensure they are properly set up
        startNode.SetWalkable(true);
        startNode.SetWeight(1);
        startNode.SetColor(startMaterial.color);

        endNode.SetWalkable(true);
        endNode.SetWeight(1);
        endNode.SetColor(endMaterial.color);
    }

    private void CreateGuaranteedStartEnd()
    {
        // Force create start node if needed
        if (grid[0, 0] == null || !grid[0, 0].walkable)
        {
            CreateNode(0, 0, 0f, 0f, false);
            grid[0, 0].SetWalkable(true);
            grid[0, 0].SetWeight(1);
        }

        // Force create end node if needed  
        if (grid[width - 1, height - 1] == null || !grid[width - 1, height - 1].walkable)
        {
            CreateNode(width - 1, height - 1, 0f, 0f, false);
            grid[width - 1, height - 1].SetWalkable(true);
            grid[width - 1, height - 1].SetWeight(1);
        }
    }

    private List<Node> GetAllWalkableNodes()
    {
        List<Node> walkableNodes = new List<Node>();
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                if (grid[x, y] != null && grid[x, y].walkable)
                {
                    walkableNodes.Add(grid[x, y]);
                }
            }
        }
        return walkableNodes;
    }

    private void GenerateBalancedMap()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                CreateNode(x, y, 0.2f, 0.2f, true);
            }
        }
        CreateGuaranteedPath();
    }

    private void GenerateCostHeavyMap()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                CreateNode(x, y, 0.1f, 0.4f, true);
            }
        }

        // Add extreme cost areas
        for (int i = 0; i < 10; i++)
        {
            int x = Random.Range(1, width - 1);
            int y = Random.Range(1, height - 1);
            if (grid[x, y] != null && grid[x, y].walkable)
            {
                grid[x, y].SetWeight(Random.Range(20, 40));
                grid[x, y].SetColor(highCostMaterial.color);
            }
        }
        CreateGuaranteedPath();
    }

    private void GenerateMazeMap()
    {
        // Create empty grid first
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                CreateNode(x, y, 0f, 0f, false);
            }
        }

        // Create maze walls
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                // Create walls in pattern, but leave paths
                if ((x % 2 == 0 || y % 2 == 0) && Random.Range(0f, 1f) < 0.55f)
                {
                    if (!IsStartOrEnd(x, y) && !IsOnGuaranteedPath(x, y))
                    {
                        grid[x, y].SetWalkable(false);
                        grid[x, y].SetColor(obstacleMaterial.color);
                    }
                }
            }
        }
    }

    private void GenerateOpenMap()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                CreateNode(x, y, 0.05f, 0f, false);
            }
        }
        CreateGuaranteedPath();
    }

    private void GenerateHeuristicTrapMap()
    {
        // Create base map
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                CreateNode(x, y, 0.15f, 0.1f, true);
            }
        }

        // Create deceptive low-cost area that leads to dead end
        int trapStartX = width / 2;
        int trapEndX = width - 2;
        int trapStartY = 1;
        int trapEndY = height / 3;

        for (int x = trapStartX; x <= trapEndX; x++)
        {
            for (int y = trapStartY; y <= trapEndY; y++)
            {
                if (grid[x, y] != null && grid[x, y].walkable)
                {
                    grid[x, y].SetWeight(1); // Very low cost - tempting!
                    grid[x, y].SetColor(walkableMaterial.color);
                }
            }
        }

        // Create the actual optimal path (high cost but direct)
        for (int x = 1; x < width - 1; x++)
        {
            int y = height / 2;
            if (grid[x, y] != null && grid[x, y].walkable)
            {
                grid[x, y].SetWeight(30); // High cost but optimal path
                grid[x, y].SetColor(highCostMaterial.color);
            }
        }
        CreateGuaranteedPath();
    }

    private void GenerateRandomChaosMap()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                CreateNode(x, y, Random.Range(0.15f, 0.35f), Random.Range(0.1f, 0.3f), true);
            }
        }
        CreateGuaranteedPath();
    }

    private void CreateNode(int x, int y, float obstacleChance, float highCostChance, bool costVariation)
    {
        // Skip if already created (for maze generation)
        if (grid[x, y] != null) return;

        Vector3 position = new Vector3(x * cellSize, 0, y * cellSize);
        GameObject nodeObj = Instantiate(nodePrefab, position, Quaternion.identity, transform);
        nodeObj.name = $"Node_{x}_{y}";

        Node node = nodeObj.GetComponent<Node>();

        int weight = 1;
        bool walkable = true;

        // Never create obstacles at guaranteed start/end positions
        if ((x == 0 && y == 0) || (x == width - 1 && y == height - 1))
        {
            walkable = true;
            weight = 1;
        }
        else
        {
            float rand = Random.Range(0f, 1f);
            if (rand < obstacleChance)
            {
                walkable = false;
            }
            else if (rand < obstacleChance + highCostChance)
            {
                weight = costVariation ? Random.Range(5, 20) : 10;
            }
        }

        node.Initialize(x, y, walkable, weight);
        grid[x, y] = node;

        // Set initial color
        if (!walkable)
        {
            node.SetColor(obstacleMaterial.color);
        }
        else if (weight > 1)
        {
            node.SetColor(highCostMaterial.color);
        }
        else
        {
            node.SetColor(walkableMaterial.color);
        }
    }

    private bool IsStartOrEnd(int x, int y)
    {
        return (x == 0 && y == 0) || (x == width - 1 && y == height - 1);
    }

    private bool IsOnGuaranteedPath(int x, int y)
    {
        // Simple L-shaped path check
        return (x == 0 && y >= 0 && y < height) || (y == height - 1 && x >= 0 && x < width);
    }

    private void CreateGuaranteedPath()
    {
        // Create a simple L-shaped guaranteed path
        int x = 0, y = 0;

        // Move right from start
        while (x < width)
        {
            EnsureWalkableNode(x, y);
            x++;
        }

        // Move up to end
        x = width - 1;
        y = 0;
        while (y < height)
        {
            EnsureWalkableNode(x, y);
            y++;
        }
    }

    private void EnsureWalkableNode(int x, int y)
    {
        if (grid[x, y] == null)
        {
            CreateNode(x, y, 0f, 0f, false);
        }
        grid[x, y].SetWalkable(true);
        grid[x, y].SetWeight(1);
        grid[x, y].SetColor(walkableMaterial.color);
    }

    public string GetMapAnalysis()
    {
        int obstacleCount = 0;
        int highCostCount = 0;
        int totalCost = 0;
        int totalNodes = width * height;

        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                if (grid[x, y] == null) continue;
                if (!grid[x, y].walkable) obstacleCount++;
                else if (grid[x, y].weight > 1)
                {
                    highCostCount++;
                    totalCost += grid[x, y].weight;
                }
            }
        }

        float obstaclePercent = (float)obstacleCount / totalNodes;
        float highCostPercent = (float)highCostCount / totalNodes;
        int startEndDistance = GetDistance(startNode.x, startNode.y, endNode.x, endNode.y);
        float avgCost = highCostCount > 0 ? (float)totalCost / highCostCount : 1f;

        return $@"MAP TYPE: {GetMapTypeName(currentMapType)}
OBSTACLES: {obstaclePercent * 100:F1}%
HIGH COST: {highCostPercent * 100:F1}% (avg: {avgCost:F1})
DISTANCE: {startEndDistance} steps";
    }

    private string GetMapTypeName(int mapType)
    {
        string[] names = { "Balanced", "Cost-Heavy", "Maze", "Open Field", "Heuristic Trap", "Random Chaos" };
        return mapType >= 0 && mapType < names.Length ? names[mapType] : "Unknown";
    }

    public List<Node> GetNeighbors(Node node)
    {
        List<Node> neighbors = new List<Node>();

        Vector2Int[] directions = {
            new Vector2Int(0, 1), new Vector2Int(1, 0),
            new Vector2Int(0, -1), new Vector2Int(-1, 0)
        };

        foreach (Vector2Int dir in directions)
        {
            int checkX = node.x + dir.x;
            int checkY = node.y + dir.y;

            if (checkX >= 0 && checkX < width && checkY >= 0 && checkY < height && grid[checkX, checkY] != null)
            {
                neighbors.Add(grid[checkX, checkY]);
            }
        }

        return neighbors;
    }

    public void ClearVisualization()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                if (grid[x, y] == null) continue;

                if (grid[x, y] == startNode)
                    grid[x, y].SetColor(startMaterial.color);
                else if (grid[x, y] == endNode)
                    grid[x, y].SetColor(endMaterial.color);
                else if (!grid[x, y].walkable)
                    grid[x, y].SetColor(obstacleMaterial.color);
                else if (grid[x, y].weight > 1)
                    grid[x, y].SetColor(highCostMaterial.color);
                else
                    grid[x, y].SetColor(walkableMaterial.color);
            }
        }
    }

    public Node GetStartNode() => startNode;
    public Node GetEndNode() => endNode;

    private int GetDistance(int x1, int y1, int x2, int y2)
    {
        int dstX = Mathf.Abs(x1 - x2);
        int dstY = Mathf.Abs(y1 - y2);
        return dstX + dstY;
    }
}