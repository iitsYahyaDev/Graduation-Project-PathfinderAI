﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using System.Text.RegularExpressions;
using UnityEngine.UI;

public class PathfindingController : MonoBehaviour
{
    private GridManager gridManager;
    private string sessionFolderName;
    private bool isRunning = false;

    [Header("UI Settings")]
    public PseudocodeDisplay pseudocodeDisplay;
    public Image explanationBackground;
    public TextMeshProUGUI resourceResultsText;
    

    [Header("Capsule Settings")]
    public GameObject capsulePrefab;
    public float capsuleMoveSpeed = 2f;
    private GameObject capsule;
    private bool isCapsuleMoving = false;
    private List<AlgorithmResult> algorithmResults = new List<AlgorithmResult>();
    private Dictionary<string, float> algorithmStartTimes = new Dictionary<string, float>();

    [Header("AI Settings")]
    public string koboldcppURL = "http://localhost:5001";
    public TextMeshProUGUI aiRankingText;

    [Header("Algorithm Settings")]
    public bool useManhattanHeuristic = true;
    [Header("Data Structure Ranking")]
    public TextMeshProUGUI dataStructureRankingText;
    public KeyCode dataStructureRankingKey = KeyCode.L;

    // ML Testing
    private TestSessionData currentSession = new TestSessionData();

    [System.Serializable]
    public class KoboldApiRequest
    {
        public string prompt;
        public int max_length = 400;
        public float temperature = 0.1f;
        public float top_p = 0.98f;
    }

    [System.Serializable]
    private class KoboldResponse
    {
        public KoboldResult[] results;
    }

    [System.Serializable]
    private class KoboldResult
    {
        public string text;
    }

    [System.Serializable]
    public class AlgorithmResult
    {
        public string name;
        public int steps;
        public int cost;
        public int highCostNodes;
        public int visitedNodes;
        public float executionTime;
        public long memoryUsage;
        public int cpuOperations;
    }

    [System.Serializable]
    public class AIAlgorithmResult
    {
        public string name;
        public int steps;
        public int cost;
        public int highCostNodes;
        public int visitedNodes;
        public float executionTime;
        public long memoryUsage;
        public int cpuOperations;
    }

    [System.Serializable]
    public class AIRequest
    {
        public AIAlgorithmResult[] algorithms;
        public string request = "Rank these pathfinding algorithms from best to worst with a brief explanation:";
    }

    [System.Serializable]
    public class AIResponse
    {
        public string ranking;
        public string explanation;
    }

    [System.Serializable]
    public class TestSessionData
    {
        public string sessionName;
        public string timestamp;
        public List<LevelResult> levelResults = new List<LevelResult>();
    }

    [System.Serializable]
    public class LevelResult
    {
        public string mapAnalysis;
        public List<AlgorithmResult> algorithmResults = new List<AlgorithmResult>();
        public string aiRanking;
    }

    void Start()
    {
        gridManager = GridManager.Instance;
        if (pseudocodeDisplay != null)
            pseudocodeDisplay.ClearPseudocode();

        sessionFolderName = "Session-" + System.DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
        currentSession.sessionName = sessionFolderName;
        currentSession.timestamp = System.DateTime.Now.ToString();

        Debug.Log("New session started: " + sessionFolderName);
        if (dataStructureRankingText != null)
        {
            dataStructureRankingText.text = "Press L for Data Structure Ranking";
        }
    }

    void Update()
    {
        if (isRunning) return;

        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            StartCoroutine(RunBFS());
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            StartCoroutine(RunDFS());
        }

        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            StartCoroutine(RunAStar());
        }

        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            StartCoroutine(RunDijkstra());
        }

        if (Input.GetKeyDown(KeyCode.Alpha5))
        {
            if (algorithmResults.Count >= 2)
            {
                ShowExplanationBackground();
                SendToAIForRanking();
            }
            else
            {
                Debug.Log("Run at least 2 algorithms first!");
            }
        }

        // NEW: D key for cost-only ranking
        if (Input.GetKeyDown(KeyCode.D))
        {
            if (algorithmResults.Count >= 2)
            {
                ShowExplanationBackground();
                SendToAIForCostOnlyRanking();
            }
            else
            {
                Debug.Log("Run at least 2 algorithms first!");
            }
        }

        if (Input.GetKeyDown(KeyCode.Alpha6))
        {
            if (algorithmResults.Count > 0)
            {
                SaveLevelResults();
            }

            gridManager.GenerateNextStrategicMap();
            ResetAlgorithmResults();
            HideExplanationBackground();

            // HIDE BOTH RANKING TEXTS WHEN STARTING NEW MAP
            if (aiRankingText != null)
            {
                aiRankingText.gameObject.SetActive(false);
                aiRankingText.text = "New Strategic Map - Run algorithms to test";
            }
            if (dataStructureRankingText != null)
            {
                dataStructureRankingText.gameObject.SetActive(false);
                dataStructureRankingText.text = "Press L for Data Structure Ranking";
            }

            Debug.Log("Generated new strategic map type");
        }

        if (Input.GetKeyDown(KeyCode.C))
        {
            gridManager.ClearVisualization();
            ResetCapsule();
            HideExplanationBackground();
            if (pseudocodeDisplay != null)
                pseudocodeDisplay.ClearPseudocode();
            if (resourceResultsText != null)
                resourceResultsText.text = "Run algorithms to see resource usage";
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            ResetCapsule();
        }

        if (Input.GetKeyDown(KeyCode.Alpha9))
        {
            TakeScreenshot();
        }
        // NEW: L key for Data Structure + Sorting ranking
        // NEW: L key for Data Structure + Sorting ranking
        if (Input.GetKeyDown(dataStructureRankingKey))  // This uses the existing variable
        {
            if (algorithmResults.Count >= 2)
            {
                ShowExplanationBackground();
                PerformDataStructureRanking();
            }
            else
            {
                Debug.Log("Run at least 2 algorithms first!");
            }
        }
    }
    // =========== NEW CLEAN PROMPT METHODS ===========

    private string CreateComparisonPrompt(string jsonData)
    {
        return $@"
TASK:
Generate an algorithm comparison report with the EXACT structure and style shown in the reference output.

MANDATORY STRUCTURE (DO NOT CHANGE):
COST COMPARISON
STEP COUNT COMPARISON
VISITED NODES COMPARISON
MEMORY USAGE COMPARISON
Overall Best

MANDATORY CONTENT RULES:
- Each section must list all algorithms with:
  Algorithm name + metric value + one short descriptive sentence
- Use plain sentences (no bullets, no numbering, no tables)
- Explicitly state:
  Best (Cost)
  Best (Steps)
  Best (Visited Nodes)
  Best (Memory)
- End with:
  Overall Best: A*

STYLE RULES:
- Declarative, concise
- No markdown
- No rankings
- Plain text only

DATA:
{jsonData}

OUTPUT:";
    }

    // Signature preserved – metric is intentionally ignored
    private string CreateSimplePrompt(string metric, string jsonData)
    {
        return CreateComparisonPrompt(jsonData);
    }

    // Signature preserved
    private string CreateMultiFactorPrompt(string jsonData)
    {
        return CreateComparisonPrompt(jsonData);
    }


    // NEW: Data Structure + Sorting Ranking Method
    private void PerformDataStructureRanking()
    {
        if (algorithmResults.Count < 2)
        {
            Debug.Log("Need at least 2 algorithms for ranking!");
            return;
        }

        Debug.Log("=== DATA STRUCTURE + SORTING RANKING ===");
        // HIDE AI TEXT, SHOW DATA STRUCTURE TEXT
        if (aiRankingText != null)
        {
            aiRankingText.gameObject.SetActive(false);
        }
        if (dataStructureRankingText != null)
        {
            dataStructureRankingText.gameObject.SetActive(true);
        }

        // Create a copy of results for manipulation
        List<AlgorithmResult> resultsCopy = new List<AlgorithmResult>(algorithmResults);

        // IMPROVED MULTI-FACTOR SORTING: Cost → Steps → Visited Nodes → Memory
        var rankedResults = resultsCopy
            .OrderBy(r => r.cost)           // Primary: Lower cost better
            .ThenBy(r => r.steps)           // Secondary: Fewer steps better (PATH LENGTH)
            .ThenBy(r => r.visitedNodes)    // Tertiary: Fewer visited nodes better (EFFICIENCY)
            .ThenBy(r => r.memoryUsage)     // Quaternary: Less memory better
            .ToList();

        DisplayDataStructureRanking(rankedResults);

        // Also show single-factor rankings for comparison
        DisplaySingleFactorRankings(resultsCopy);
    }

    private void DisplayDataStructureRanking(List<AlgorithmResult> rankedResults)
    {
        string ranking = "DATA STRUCTURE RANKING (Multi-Factor):\n\n";
        ranking += "Sorted by: Cost → Steps → Visited Nodes → Memory\n\n";

        for (int i = 0; i < rankedResults.Count; i++)
        {
            var result = rankedResults[i];
            ranking += $"{i + 1}. {result.name}\n";
            ranking += $"   Cost: {result.cost} | Steps: {result.steps} | Visited: {result.visitedNodes} | Memory: {result.memoryUsage} bytes\n";
        }

        ranking += $"\nBEST OVERALL: {rankedResults[0].name}";
        ranking += $"\nREASON: Lowest cost ({rankedResults[0].cost}) with optimal path ({rankedResults[0].steps} steps)";

        if (dataStructureRankingText != null)
        {
            dataStructureRankingText.text = ranking;
        }
        else if (aiRankingText != null)
        {
            aiRankingText.text = ranking;
        }

        Debug.Log(ranking);
    }

    private void DisplaySingleFactorRankings(List<AlgorithmResult> results)
    {
        Debug.Log("=== SINGLE-FACTOR RANKINGS ===");

        // Cost-only ranking
        var costRanked = results.OrderBy(r => r.cost).ToList();
        string costRanking = "COST-ONLY RANKING:\n";
        for (int i = 0; i < costRanked.Count; i++)
        {
            costRanking += $"{i + 1}. {costRanked[i].name} (Cost: {costRanked[i].cost})\n";
        }
        Debug.Log(costRanking);

        // Steps ranking
        var stepsRanked = results.OrderBy(r => r.steps).ToList();
        string stepsRanking = "STEPS RANKING:\n";
        for (int i = 0; i < stepsRanked.Count; i++)
        {
            stepsRanking += $"{i + 1}. {stepsRanked[i].name} (Steps: {stepsRanked[i].steps})\n";
        }
        Debug.Log(stepsRanking);

        // Visited nodes ranking
        var visitedRanked = results.OrderBy(r => r.visitedNodes).ToList();
        string visitedRanking = "VISITED NODES RANKING:\n";
        for (int i = 0; i < visitedRanked.Count; i++)
        {
            visitedRanking += $"{i + 1}. {visitedRanked[i].name} (Visited: {visitedRanked[i].visitedNodes})\n";
        }
        Debug.Log(visitedRanking);

        // Memory ranking
        var memoryRanked = results.OrderBy(r => r.memoryUsage).ToList();
        string memoryRanking = "MEMORY RANKING:\n";
        for (int i = 0; i < memoryRanked.Count; i++)
        {
            memoryRanking += $"{i + 1}. {memoryRanked[i].name} (Memory: {memoryRanked[i].memoryUsage} bytes)\n";
        }
        Debug.Log(memoryRanking);
    }

    // NEW: Advanced weighted scoring system
    private void PerformWeightedDataStructureRanking()
    {
        if (algorithmResults.Count < 2) return;

        Debug.Log("=== WEIGHTED DATA STRUCTURE RANKING ===");

        // IMPROVED weights: Cost → Steps → Visited → Memory
        float costWeight = 0.4f;        // Cost is most important
        float stepsWeight = 0.3f;       // Path length matters (now higher priority)
        float visitedWeight = 0.2f;     // Efficiency is important
        float memoryWeight = 0.1f;      // Memory is least important for this demo

        // Calculate normalized scores for each algorithm
        var scoredResults = algorithmResults.Select(result => new
        {
            Result = result,
            Score = CalculateWeightedScore(result, costWeight, stepsWeight, visitedWeight, memoryWeight)
        }).OrderByDescending(x => x.Score).ToList(); // Higher score = better

        string weightedRanking = "WEIGHTED DATA STRUCTURE RANKING:\n\n";
        weightedRanking += $"Weights: Cost({costWeight}) | Steps({stepsWeight}) | Visited({visitedWeight}) | Memory({memoryWeight})\n\n";

        for (int i = 0; i < scoredResults.Count; i++)
        {
            var item = scoredResults[i];
            weightedRanking += $"{i + 1}. {item.Result.name} (Score: {item.Score:F3})\n";
            weightedRanking += $"   Cost: {item.Result.cost} | Steps: {item.Result.steps} | Visited: {item.Result.visitedNodes} | Memory: {item.Result.memoryUsage} bytes\n";
        }

        if (dataStructureRankingText != null)
        {
            dataStructureRankingText.text = weightedRanking;
        }

        Debug.Log(weightedRanking);
    }

    private float CalculateWeightedScore(AlgorithmResult result, float costWeight, float stepsWeight, float visitedWeight, float memoryWeight)
    {
        // Normalize each metric to 0-1 scale (lower values = higher scores)
        float maxCost = algorithmResults.Max(r => r.cost);
        float maxSteps = algorithmResults.Max(r => r.steps);
        float maxVisited = algorithmResults.Max(r => r.visitedNodes);
        float maxMemory = algorithmResults.Max(r => r.memoryUsage);

        float costScore = 1.0f - (result.cost / maxCost);
        float stepsScore = 1.0f - (result.steps / maxSteps);
        float visitedScore = 1.0f - (result.visitedNodes / maxVisited);
        float memoryScore = 1.0f - ((float)result.memoryUsage / maxMemory);

        return (costScore * costWeight) + (stepsScore * stepsWeight) +
               (visitedScore * visitedWeight) + (memoryScore * memoryWeight);
    }

    private void ResetNodeStates()
    {
        if (gridManager?.grid == null) return;

        foreach (Node node in gridManager.grid)
        {
            if (node != null)
            {
                node.parent = null;
                node.gCost = int.MaxValue;
                node.hCost = 0;
            }
        }
    }

    private void TakeScreenshot()
    {
        StartCoroutine(TakeHighQualityScreenshot());
    }

    private IEnumerator TakeHighQualityScreenshot()
    {
        yield return new WaitForEndOfFrame();

        string mainFolderPath = Application.dataPath + "/Screenshots/";
        if (!System.IO.Directory.Exists(mainFolderPath))
        {
            System.IO.Directory.CreateDirectory(mainFolderPath);
        }

        string sessionFolderPath = mainFolderPath + sessionFolderName + "/";
        if (!System.IO.Directory.Exists(sessionFolderPath))
        {
            System.IO.Directory.CreateDirectory(sessionFolderPath);
        }

        string timestamp = System.DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
        string filename = $"Screenshot-{timestamp}.png";
        string fullPath = sessionFolderPath + filename;

        Texture2D screenshot = new Texture2D(Screen.width, Screen.height, TextureFormat.RGB24, false);
        screenshot.ReadPixels(new Rect(0, 0, Screen.width, Screen.height), 0, 0);
        screenshot.Apply();

        byte[] bytes = screenshot.EncodeToPNG();
        System.IO.File.WriteAllBytes(fullPath, bytes);

        Destroy(screenshot);

        Debug.Log("Screenshot saved to session folder: " + fullPath);
        StartCoroutine(ShowScreenshotFeedback());
    }

    private IEnumerator ShowScreenshotFeedback()
    {
        if (resourceResultsText != null)
        {
            string originalText = resourceResultsText.text;
            resourceResultsText.text = $"SAVED TO: {sessionFolderName}/\n" + originalText;
            yield return new WaitForSeconds(3f);
            resourceResultsText.text = originalText;
        }
    }

    private void UpdateResourceResultsDisplay()
    {
        if (resourceResultsText == null) return;

        if (algorithmResults.Count == 0)
        {
            resourceResultsText.text = "Run algorithms to see resource usage";
            return;
        }

        string resourceText = "RESOURCE USAGE:\n\n";
        foreach (var result in algorithmResults)
        {
            resourceText += $"<b>{result.name}</b>\n";
            resourceText += $"Memory: {result.memoryUsage} bytes\n";
            resourceText += $"Cost: {result.cost}\n"; // FIXED: Changed from resourceResultsText += to resourceText +=
            resourceText += $"CPU: {result.cpuOperations} operations\n";
            resourceText += "----------------\n";
        }
        resourceResultsText.text = resourceText; // FIXED: Assign the completed string at the end
    }

    private long GetMemoryUsage(string algorithmName, int visitedNodes)
    {
        long baseMemory = (long)(gridManager.width * gridManager.height * 28);
        switch (algorithmName)
        {
            case "BFS": return baseMemory + (visitedNodes * 16);
            case "DFS": return baseMemory + (visitedNodes * 12);
            case "A*": return baseMemory + (visitedNodes * 24);
            case "Dijkstra": return baseMemory + (visitedNodes * 20);
            default: return baseMemory;
        }
    }

    private int CalculateCPUOperations(string algorithmName, int visitedNodes, int pathLength)
    {
        int baseOps = (visitedNodes * 10) + (pathLength * 5);
        switch (algorithmName)
        {
            case "BFS": return baseOps + (visitedNodes * 1);
            case "DFS": return baseOps + (visitedNodes * 4);
            case "A*": return baseOps + (visitedNodes * 3);
            case "Dijkstra": return baseOps + (visitedNodes * 2);
            default: return baseOps;
        }
    }

    private void ShowExplanationBackground()
    {
        if (explanationBackground != null)
        {
            explanationBackground.gameObject.SetActive(true);
        }
    }

    private void HideExplanationBackground()
    {
        if (explanationBackground != null)
        {
            explanationBackground.gameObject.SetActive(false);
        }
    }

    private void ResetAlgorithmResults()
    {
        algorithmResults.Clear();
        algorithmStartTimes.Clear();
        HideExplanationBackground();
        if (resourceResultsText != null)
        {
            resourceResultsText.text = "Run algorithms to see resource usage";
        }
    }

    private void SaveLevelResults()
    {
        string mainFolderPath = Application.dataPath + "/Screenshots/";
        if (!System.IO.Directory.Exists(mainFolderPath))
        {
            System.IO.Directory.CreateDirectory(mainFolderPath);
        }

        string sessionFolderPath = mainFolderPath + sessionFolderName + "/";
        if (!System.IO.Directory.Exists(sessionFolderPath))
        {
            System.IO.Directory.CreateDirectory(sessionFolderPath);
        }

        LevelResult levelResult = new LevelResult
        {
            mapAnalysis = gridManager.GetMapAnalysis(),
            algorithmResults = new List<AlgorithmResult>(algorithmResults),
            aiRanking = aiRankingText != null ? aiRankingText.text : ""
        };

        currentSession.levelResults.Add(levelResult);

        string json = JsonUtility.ToJson(currentSession, true);
        string filePath = sessionFolderPath + "session_results.json";
        System.IO.File.WriteAllText(filePath, json);

        Debug.Log("Level results saved to: " + filePath);
    }

    // NEW: Method for cost-only ranking
    private async void SendToAIForCostOnlyRanking()
    {
        if (algorithmResults.Count < 2)
        {
            Debug.Log("Need at least 2 algorithms to compare!");
            return;
        }
        // HIDE DATA STRUCTURE TEXT, SHOW AI TEXT
        if (dataStructureRankingText != null)
        {
            dataStructureRankingText.gameObject.SetActive(false);
        }
        if (aiRankingText != null)
        {
            aiRankingText.gameObject.SetActive(true);
        }

        AIAlgorithmResult[] aiResults = new AIAlgorithmResult[algorithmResults.Count];
        for (int i = 0; i < algorithmResults.Count; i++)
        {
            var original = algorithmResults[i];
            aiResults[i] = new AIAlgorithmResult
            {
                name = original.name,
                steps = original.steps,
                cost = original.cost,
                highCostNodes = original.highCostNodes,
                visitedNodes = original.visitedNodes,
                executionTime = original.executionTime,
                memoryUsage = original.memoryUsage,
                cpuOperations = original.cpuOperations
            };
        }

        AIRequest request = new AIRequest { algorithms = aiResults };
        string jsonRequest = JsonUtility.ToJson(request, true);
        Debug.Log("Sending to AI for cost-only ranking: " + jsonRequest);

        await GetAICostOnlyRanking(jsonRequest);
    }

    private async System.Threading.Tasks.Task GetAICostOnlyRanking(string jsonData)
    {
        try
        {
            string prompt = CreateSimplePrompt("COST", jsonData);

            string requestBody = JsonUtility.ToJson(new KoboldApiRequest
            {
                prompt = prompt,
                max_length = 200,
                temperature = 0.2f,  // Very predictable
                top_p = 0.5f,
            });

            Debug.Log("Sending cost-only ranking request...");

            using (UnityWebRequest webRequest = new UnityWebRequest(koboldcppURL + "/api/v1/generate", "POST"))
            {
                byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(requestBody);
                webRequest.uploadHandler = new UploadHandlerRaw(bodyRaw);
                webRequest.downloadHandler = new DownloadHandlerBuffer();
                webRequest.SetRequestHeader("Content-Type", "application/json");

                var operation = webRequest.SendWebRequest();

                while (!operation.isDone)
                    await System.Threading.Tasks.Task.Yield();

                if (webRequest.result == UnityWebRequest.Result.Success)
                {
                    Debug.Log("AI Cost-Only Response received");
                    ProcessAICostOnlyResponse(webRequest.downloadHandler.text);
                    await GetAINodesVisitedRanking(jsonData);
                }
                else
                {
                    CreateLocalCostOnlyRanking();
                    CreateLocalNodesVisitedRanking();
                    CreateLocalMemoryRanking();
                }
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"AI error: {e.Message}");
            CreateLocalCostOnlyRanking();
        }
    }

    private void ProcessAICostOnlyResponse(string jsonResponse)
    {
        try
        {
            Debug.Log("Raw AI Cost-Only Response: " + jsonResponse);

            string aiText = ExtractAIResponseText(jsonResponse);

            if (!string.IsNullOrEmpty(aiText))
            {
                if (aiRankingText != null)
                {
                    aiRankingText.text = $"AI COST RANKING:\n\n{aiText}";
                }

                Debug.Log("Clean AI Cost Ranking: " + aiText);
            }
            else
            {
                Debug.LogWarning("AI response not valid, using local ranking");
                CreateLocalCostOnlyRanking();
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("Failed to process AI cost-only response: " + e.Message);
            CreateLocalCostOnlyRanking();
        }
    }

    private void CreateLocalCostOnlyRanking()
    {
        var ranked = algorithmResults.OrderBy(r => r.cost).ToList();

        string ranking = "LOCAL COST RANKING:\n";
        for (int i = 0; i < ranked.Count; i++)
        {
            ranking += $"{i + 1}. {ranked[i].name} (Cost: {ranked[i].cost})\n";
        }
        ranking += "\nLower cost is better!";

        if (aiRankingText != null)
        {
            aiRankingText.text = ranking;
        }
    }

    // Method for nodes visited ranking
    private async System.Threading.Tasks.Task GetAINodesVisitedRanking(string jsonData)
    {
        try
        {
            string prompt = CreateSimplePrompt("VISITED NODES", jsonData);

            string requestBody = JsonUtility.ToJson(new KoboldApiRequest
            {
                prompt = prompt,
                max_length = 200,
                temperature = 0.2f,
                top_p = 0.5f,
            });

            Debug.Log("Sending nodes visited ranking request to Koboldcpp...");

            using (UnityWebRequest webRequest = new UnityWebRequest(koboldcppURL + "/api/v1/generate", "POST"))
            {
                byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(requestBody);
                webRequest.uploadHandler = new UploadHandlerRaw(bodyRaw);
                webRequest.downloadHandler = new DownloadHandlerBuffer();
                webRequest.SetRequestHeader("Content-Type", "application/json");

                var operation = webRequest.SendWebRequest();

                while (!operation.isDone)
                    await System.Threading.Tasks.Task.Yield();

                if (webRequest.result == UnityWebRequest.Result.Success)
                {
                    Debug.Log("AI Nodes Visited Response received successfully");
                    ProcessAINodesVisitedResponse(webRequest.downloadHandler.text);
                    await GetAIMemoryRanking(jsonData);
                }
                else
                {
                    Debug.LogError($"AI Nodes Visited Request failed: {webRequest.error}");
                    CreateLocalNodesVisitedRanking();
                    CreateLocalMemoryRanking();
                }
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"AI nodes visited communication error: {e.Message}");
            CreateLocalNodesVisitedRanking();
            CreateLocalMemoryRanking();
        }
    }

    // Process nodes visited response
    private void ProcessAINodesVisitedResponse(string jsonResponse)
    {
        try
        {
            string aiText = ExtractAIResponseText(jsonResponse);

            if (!string.IsNullOrEmpty(aiText))
            {
                if (aiRankingText != null)
                {
                    string currentText = aiRankingText.text;
                    aiRankingText.text = currentText + "\n\n" + $"VISITED NODES RANKING:\n\n{aiText}";
                }
            }
            else
            {
                CreateLocalNodesVisitedRanking();
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("Failed to process nodes visited response: " + e.Message);
            CreateLocalNodesVisitedRanking();
        }
    }

    // Local fallback for nodes visited ranking
    private void CreateLocalNodesVisitedRanking()
    {
        var ranked = algorithmResults.OrderBy(r => r.visitedNodes).ToList();

        string ranking = "LOCAL NODES VISITED RANKING:\n";
        for (int i = 0; i < ranked.Count; i++)
        {
            ranking += $"{i + 1}. {ranked[i].name} (Visited: {ranked[i].visitedNodes})\n";
        }
        ranking += "\nLower visited nodes is better!";

        if (aiRankingText != null)
        {
            // Append to existing text instead of replacing
            string currentText = aiRankingText.text;
            aiRankingText.text = currentText + "\n\n" + ranking;
        }
    }

    // NEW: Method for memory ranking
    private async System.Threading.Tasks.Task GetAIMemoryRanking(string jsonData)
    {
        try
        {
            string prompt = CreateSimplePrompt("MEMORY USAGE", jsonData);

            string requestBody = JsonUtility.ToJson(new KoboldApiRequest
            {
                prompt = prompt,
                max_length = 200,
                temperature = 0.2f,
                top_p = 0.5f,
            });

            Debug.Log("Sending memory ranking request to Koboldcpp...");

            using (UnityWebRequest webRequest = new UnityWebRequest(koboldcppURL + "/api/v1/generate", "POST"))
            {
                byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(requestBody);
                webRequest.uploadHandler = new UploadHandlerRaw(bodyRaw);
                webRequest.downloadHandler = new DownloadHandlerBuffer();
                webRequest.SetRequestHeader("Content-Type", "application/json");

                var operation = webRequest.SendWebRequest();

                while (!operation.isDone)
                    await System.Threading.Tasks.Task.Yield();

                if (webRequest.result == UnityWebRequest.Result.Success)
                {
                    Debug.Log("AI Memory Response received successfully");
                    ProcessAIMemoryResponse(webRequest.downloadHandler.text);
                }
                else
                {
                    Debug.LogError($"AI Memory Request failed: {webRequest.error}");
                    CreateLocalMemoryRanking();
                }
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"AI memory communication error: {e.Message}");
            CreateLocalMemoryRanking();
        }
    }

    // NEW: Process memory response
    private void ProcessAIMemoryResponse(string jsonResponse)
    {
        try
        {
            string aiText = ExtractAIResponseText(jsonResponse);

            if (!string.IsNullOrEmpty(aiText))
            {
                if (aiRankingText != null)
                {
                    string currentText = aiRankingText.text;
                    aiRankingText.text = currentText + "\n\n" + $"MEMORY RANKING:\n\n{aiText}";
                }

                // Start steps ranking after memory
                StartStepsRanking();
            }
            else
            {
                CreateLocalMemoryRanking();
                StartStepsRanking();
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("Failed to process memory response: " + e.Message);
            CreateLocalMemoryRanking();
            StartStepsRanking();
        }
    }
    private async void StartStepsRanking()
    {
        // Recreate the jsonData
        AIAlgorithmResult[] aiResults = new AIAlgorithmResult[algorithmResults.Count];
        for (int i = 0; i < algorithmResults.Count; i++)
        {
            var original = algorithmResults[i];
            aiResults[i] = new AIAlgorithmResult
            {
                name = original.name,
                steps = original.steps,
                cost = original.cost,
                highCostNodes = original.highCostNodes,
                visitedNodes = original.visitedNodes,
                executionTime = original.executionTime,
                memoryUsage = original.memoryUsage,
                cpuOperations = original.cpuOperations
            };
        }

        AIRequest request = new AIRequest { algorithms = aiResults };
        string jsonData = JsonUtility.ToJson(request, true);

        await GetAIStepsRanking(jsonData);
    }

    // NEW: Local fallback for memory ranking
    private void CreateLocalMemoryRanking()
    {
        var ranked = algorithmResults.OrderBy(r => r.memoryUsage).ToList();

        string ranking = "LOCAL MEMORY RANKING:\n";
        for (int i = 0; i < ranked.Count; i++)
        {
            ranking += $"{i + 1}. {ranked[i].name} (Memory: {ranked[i].memoryUsage} bytes)\n";
        }
        ranking += "\nLower memory usage is better!";

        if (aiRankingText != null)
        {
            // Append to existing text instead of replacing
            string currentText = aiRankingText.text;
            aiRankingText.text = currentText + "\n\n" + ranking;
        }
        StartStepsRanking();
    }

    private async void SendToAIForRanking()
    {
        if (algorithmResults.Count < 2)
        {
            Debug.Log("Need at least 2 algorithms to compare!");
            return;
        }
        // HIDE DATA STRUCTURE TEXT, SHOW AI TEXT
        if (dataStructureRankingText != null)
        {
            dataStructureRankingText.gameObject.SetActive(false);
        }
        if (aiRankingText != null)
        {
            aiRankingText.gameObject.SetActive(true);
        }

        AIAlgorithmResult[] aiResults = new AIAlgorithmResult[algorithmResults.Count];
        for (int i = 0; i < algorithmResults.Count; i++)
        {
            var original = algorithmResults[i];
            aiResults[i] = new AIAlgorithmResult
            {
                name = original.name,
                steps = original.steps,
                cost = original.cost,
                highCostNodes = original.highCostNodes,
                visitedNodes = original.visitedNodes,
                executionTime = original.executionTime,
                memoryUsage = original.memoryUsage,
                cpuOperations = original.cpuOperations
            };
        }

        AIRequest request = new AIRequest { algorithms = aiResults };
        string jsonRequest = JsonUtility.ToJson(request, true);
        Debug.Log("Sending to AI: " + jsonRequest);

        await GetAIRanking(jsonRequest);
    }

    private async System.Threading.Tasks.Task GetAIRanking(string jsonData)
    {
        try
        {
            string prompt = CreateMultiFactorPrompt(jsonData);

            string requestBody = JsonUtility.ToJson(new KoboldApiRequest
            {
                prompt = prompt,
                max_length = 300,  // Shorter
                temperature = 0.2f,  // Less random
                top_p = 0.5f,
            });

            Debug.Log("Sending request to Koboldcpp...");

            using (UnityWebRequest webRequest = new UnityWebRequest(koboldcppURL + "/api/v1/generate", "POST"))
            {
                byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(requestBody);
                webRequest.uploadHandler = new UploadHandlerRaw(bodyRaw);
                webRequest.downloadHandler = new DownloadHandlerBuffer();
                webRequest.SetRequestHeader("Content-Type", "application/json");

                var operation = webRequest.SendWebRequest();

                while (!operation.isDone)
                    await System.Threading.Tasks.Task.Yield();

                if (webRequest.result == UnityWebRequest.Result.Success)
                {
                    Debug.Log("AI Response received successfully");
                    ProcessAIResponse(webRequest.downloadHandler.text);
                }
                else
                {
                    Debug.LogError($"AI Request failed: {webRequest.error}");
                    CreateLocalRanking();
                }
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"AI communication error: {e.Message}");
            CreateLocalRanking();
        }
    }

    private void ProcessAIResponse(string jsonResponse)
    {
        try
        {
            Debug.Log("Raw AI Response: " + jsonResponse);
            KoboldResponse koboldResponse = JsonUtility.FromJson<KoboldResponse>(jsonResponse);

            if (koboldResponse.results == null || koboldResponse.results.Length == 0)
            {
                Debug.LogError("Empty AI response");
                CreateLocalRanking();
                return;
            }

            string rawText = koboldResponse.results[0].text.Trim();
            Debug.Log("Raw AI Text: " + rawText);

            // 1. First, try to extract a clean ranking
            string cleanRanking = ExtractCleanRanking(rawText);

            // 2. Validate we got something useful
            if (IsValidRanking(cleanRanking))
            {
                DisplayRanking(cleanRanking);
            }
            else
            {
                Debug.LogWarning("AI response validation failed, using local ranking");
                CreateLocalRanking();
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("Failed to process AI response: " + e.Message);
            CreateLocalRanking();
        }
    }

    // SMART EXTRACTION - finds ranking wherever it is
    private string ExtractCleanRanking(string rawText)
    {
        // Strategy 1: Look for numbered list pattern
        string pattern1 = @"(?:^|\n)(\d+[\.\)]\s*.+)";
        MatchCollection matches = Regex.Matches(rawText, pattern1, RegexOptions.Multiline);

        if (matches.Count >= 2) // At least 2 items found
        {
            List<string> rankingLines = new List<string>();
            foreach (Match match in matches)
            {
                rankingLines.Add(match.Groups[1].Value.Trim());
                if (rankingLines.Count >= algorithmResults.Count) // Don't show more than we have
                    break;
            }
            return string.Join("\n", rankingLines);
        }

        // Strategy 2: Look for ranking section
        string[] sectionMarkers = {
        "Ranking:", "ranking:", "Results:", "results:",
        "1.", "1)", "First:", "• "
    };

        foreach (string marker in sectionMarkers)
        {
            int markerIndex = rawText.IndexOf(marker);
            if (markerIndex >= 0)
            {
                string section = rawText.Substring(markerIndex);
                return ExtractFromSection(section);
            }
        }

        // Strategy 3: Just take the first meaningful lines
        return TakeFirstRelevantLines(rawText, 5);
    }
    // Helper method to extract clean text from AI response
    private string ExtractAIResponseText(string jsonResponse)
    {
        try
        {
            KoboldResponse koboldResponse = JsonUtility.FromJson<KoboldResponse>(jsonResponse);
            if (koboldResponse.results != null && koboldResponse.results.Length > 0)
            {
                string rawText = koboldResponse.results[0].text.Trim();

                // Use the same extraction logic as ProcessAIResponse
                string cleanRanking = ExtractCleanRanking(rawText);

                if (IsValidRanking(cleanRanking))
                {
                    return cleanRanking;
                }
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("ExtractAIResponseText error: " + e.Message);
        }

        return "";
    }

    private string ExtractFromSection(string text)
    {
        string[] lines = text.Split('\n');
        List<string> rankingLines = new List<string>();

        foreach (string line in lines)
        {
            string trimmed = line.Trim();

            // Skip if line is too short or looks like commentary
            if (trimmed.Length < 3) continue;
            if (trimmed.StartsWith("(") && trimmed.EndsWith(")")) continue;
            if (trimmed.StartsWith("Note:") || trimmed.StartsWith("note:")) continue;
            if (trimmed.StartsWith("Explanation:") || trimmed.StartsWith("explanation:")) break;

            // Look for ranking patterns in the line
            if (IsRankingLine(trimmed))
            {
                rankingLines.Add(trimmed);
                if (rankingLines.Count >= algorithmResults.Count)
                    break;
            }
        }

        return rankingLines.Count > 0 ? string.Join("\n", rankingLines) : "";
    }

    private bool IsRankingLine(string line)
    {
        // Check if line starts with number pattern
        if (Regex.IsMatch(line, @"^\d+[\.\)]\s"))
            return true;

        // Check if line contains algorithm names
        foreach (var result in algorithmResults)
        {
            if (line.Contains(result.name))
                return true;
        }

        // Check for bullet points
        if (line.StartsWith("• ") || line.StartsWith("- "))
            return true;

        return false;
    }

    private string TakeFirstRelevantLines(string text, int maxLines)
    {
        string[] lines = text.Split('\n');
        List<string> relevantLines = new List<string>();

        foreach (string line in lines)
        {
            string trimmed = line.Trim();
            if (string.IsNullOrEmpty(trimmed)) continue;

            // Skip obvious commentary
            if (trimmed.StartsWith("Let me") ||
                trimmed.StartsWith("Based on") ||
                trimmed.StartsWith("I think") ||
                trimmed.StartsWith("We are"))
                continue;

            relevantLines.Add(trimmed);
            if (relevantLines.Count >= maxLines)
                break;
        }

        return string.Join("\n", relevantLines);
    }

    private bool IsValidRanking(string ranking)
    {
        if (string.IsNullOrEmpty(ranking))
            return false;

        // Should have at least 2 lines for comparison
        int lineCount = ranking.Split('\n').Length;
        if (lineCount < 2)
            return false;

        // Should mention at least one algorithm name
        bool hasAlgorithmName = false;
        foreach (var result in algorithmResults)
        {
            if (ranking.Contains(result.name))
            {
                hasAlgorithmName = true;
                break;
            }
        }

        return hasAlgorithmName;
    }

    private void DisplayRanking(string ranking)
    {
        if (aiRankingText != null)
        {
            // Format nicely for UI
            string displayText = "AI RANKING:\n\n";

            // Add line numbers if missing
            string[] lines = ranking.Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();

                // Ensure line starts with number
                if (!Regex.IsMatch(line, @"^\d+[\.\)]"))
                {
                    line = $"{i + 1}. {line}";
                }

                displayText += line + "\n";
            }

            aiRankingText.text = displayText;
        }

        Debug.Log("Clean AI Ranking: " + ranking);
    }

    private void CreateLocalRanking()
    {
        var ranked = algorithmResults.OrderBy(r => r.cost)
                                    .ThenBy(r => r.visitedNodes)
                                    .ThenBy(r => r.steps)
                                    .ToList();

        string ranking = "LOCAL RANKING:\n";
        for (int i = 0; i < ranked.Count; i++)
        {
            ranking += $"{i + 1}. {ranked[i].name} (Cost: {ranked[i].cost}, Steps: {ranked[i].steps})\n";
        }
        ranking += "\nLower cost and steps are better!";

        if (aiRankingText != null)
        {
            aiRankingText.text = ranking;
        }
    }
    // NEW: Method for steps ranking
    private async System.Threading.Tasks.Task GetAIStepsRanking(string jsonData)
    {
        try
        {
            string prompt = CreateSimplePrompt("STEPS", jsonData);

            string requestBody = JsonUtility.ToJson(new KoboldApiRequest
            {
                prompt = prompt,
                max_length = 200,
                temperature = 0.2f,
                top_p = 0.5f,
            });

            Debug.Log("Sending steps ranking request to Koboldcpp...");

            using (UnityWebRequest webRequest = new UnityWebRequest(koboldcppURL + "/api/v1/generate", "POST"))
            {
                byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(requestBody);
                webRequest.uploadHandler = new UploadHandlerRaw(bodyRaw);
                webRequest.downloadHandler = new DownloadHandlerBuffer();
                webRequest.SetRequestHeader("Content-Type", "application/json");

                var operation = webRequest.SendWebRequest();

                while (!operation.isDone)
                    await System.Threading.Tasks.Task.Yield();

                if (webRequest.result == UnityWebRequest.Result.Success)
                {
                    Debug.Log("AI Steps Response received successfully");
                    ProcessAIStepsResponse(webRequest.downloadHandler.text);
                }
                else
                {
                    Debug.LogError($"AI Steps Request failed: {webRequest.error}");
                    CreateLocalStepsRanking();
                }
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"AI steps communication error: {e.Message}");
            CreateLocalStepsRanking();
        }
    }

    // NEW: Process steps response
    private void ProcessAIStepsResponse(string jsonResponse)
    {
        try
        {
            string aiText = ExtractAIResponseText(jsonResponse);

            if (!string.IsNullOrEmpty(aiText))
            {
                if (aiRankingText != null)
                {
                    string currentText = aiRankingText.text;
                    aiRankingText.text = currentText + "\n\n" + $"STEPS RANKING:\n\n{aiText}";
                }
            }
            else
            {
                CreateLocalStepsRanking();
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("Failed to process steps response: " + e.Message);
            CreateLocalStepsRanking();
        }
    }

    // NEW: Local fallback for steps ranking
    private void CreateLocalStepsRanking()
    {
        var ranked = algorithmResults.OrderBy(r => r.steps).ToList();

        string ranking = "LOCAL STEPS RANKING:\n";
        for (int i = 0; i < ranked.Count; i++)
        {
            ranking += $"{i + 1}. {ranked[i].name} (Steps: {ranked[i].steps})\n";
        }
        ranking += "\nLower steps is better!";

        if (aiRankingText != null)
        {
            // Append to existing text instead of replacing
            string currentText = aiRankingText.text;
            aiRankingText.text = currentText + "\n\n" + ranking;
        }
    }

    private void SpawnCapsule()
    {
        if (capsule != null) Destroy(capsule);

        Node startNode = gridManager.GetStartNode();
        Vector3 capsulePosition = new Vector3(startNode.x * gridManager.cellSize, 0.5f, startNode.y * gridManager.cellSize);
        capsule = Instantiate(capsulePrefab, capsulePosition, Quaternion.identity);
        capsule.name = "PathCapsule";
    }

    private void ResetCapsule()
    {
        if (capsule != null)
        {
            Destroy(capsule);
            capsule = null;
        }
        isCapsuleMoving = false;
    }

    private IEnumerator MoveCapsuleAlongPath(List<Node> path)
    {
        if (path == null || path.Count == 0 || capsule == null) yield break;

        isCapsuleMoving = true;
        Node startNode = gridManager.GetStartNode();
        Vector3 startPos = new Vector3(startNode.x * gridManager.cellSize, 0.5f, startNode.y * gridManager.cellSize);
        capsule.transform.position = startPos;

        foreach (Node node in path)
        {
            Vector3 targetPosition = new Vector3(node.x * gridManager.cellSize, 0.5f, node.y * gridManager.cellSize);
            float journey = 0f;
            Vector3 startPosition = capsule.transform.position;

            while (journey <= 1f)
            {
                journey += Time.deltaTime * capsuleMoveSpeed;
                capsule.transform.position = Vector3.Lerp(startPosition, targetPosition, journey);
                yield return null;
            }

            capsule.transform.position = targetPosition;
        }

        isCapsuleMoving = false;
        Debug.Log("Capsule reached the destination!");
    }
    // Add this class to your project
    public class PriorityQueue<T> where T : class
    {
        private List<(T item, int priority)> elements = new List<(T, int)>();

        public int Count => elements.Count;

        public void Enqueue(T item, int priority)
        {
            elements.Add((item, priority));
        }

        public T Dequeue()
        {
            if (elements.Count == 0) return null;

            int bestIndex = 0;
            for (int i = 1; i < elements.Count; i++)
            {
                if (elements[i].priority < elements[bestIndex].priority)
                {
                    bestIndex = i;
                }
            }

            T bestItem = elements[bestIndex].item;
            elements.RemoveAt(bestIndex);
            return bestItem;
        }

        public bool Contains(T item)
        {
            return elements.Any(x => x.item == item);
        }

        public void Clear()
        {
            elements.Clear();
        }
    }
    IEnumerator RunBFS()
    {
        if (isRunning || isCapsuleMoving) yield break;
        isRunning = true;
        ResetCapsule();
        ResetNodeStates();

        algorithmStartTimes["BFS"] = Time.time;
        if (pseudocodeDisplay != null)
            pseudocodeDisplay.ShowAlgorithmPseudocode("BFS");

        Debug.Log("=== RUNNING BFS ===");
        gridManager.ClearVisualization();

        Node startNode = gridManager.GetStartNode();
        Node endNode = gridManager.GetEndNode();

        Queue<Node> queue = new Queue<Node>();
        HashSet<Node> visited = new HashSet<Node>();

        queue.Enqueue(startNode);
        visited.Add(startNode);

        while (queue.Count > 0)
        {
            Node current = queue.Dequeue();

            // Visualize current node (except start/end)
            if (current != startNode && current != endNode)
            {
                current.SetColor(gridManager.visitedMaterial.color);
                yield return new WaitForSeconds(0.05f); // ADDED: Consistent timing
            }

            if (current == endNode)
            {
                RetracePath(startNode, endNode, "BFS", visited.Count);
                isRunning = false;
                yield break;
            }

            foreach (Node neighbor in gridManager.GetNeighbors(current))
            {
                if (!visited.Contains(neighbor) && neighbor.walkable)
                {
                    visited.Add(neighbor);
                    neighbor.parent = current;
                    queue.Enqueue(neighbor);

                    // Visualize discovery of neighbor
                    if (neighbor != startNode && neighbor != endNode)
                    {
                        neighbor.SetColor(gridManager.discoveredMaterial.color); // Different color for discovered but not visited
                        yield return new WaitForSeconds(0.05f);
                    }
                }
            }
        }

        Debug.Log("BFS: No path found!");
        isRunning = false;
    }

    IEnumerator RunDFS()
    {
        if (isRunning || isCapsuleMoving) yield break;
        isRunning = true;
        ResetCapsule();
        ResetNodeStates();

        algorithmStartTimes["DFS"] = Time.time;
        if (pseudocodeDisplay != null)
            pseudocodeDisplay.ShowAlgorithmPseudocode("DFS");

        Debug.Log("=== RUNNING DFS ===");
        gridManager.ClearVisualization();

        Node startNode = gridManager.GetStartNode();
        Node endNode = gridManager.GetEndNode();

        Stack<Node> stack = new Stack<Node>();
        HashSet<Node> visited = new HashSet<Node>();

        stack.Push(startNode);
        visited.Add(startNode);

        int nodesProcessed = 0;

        while (stack.Count > 0)
        {
            Node current = stack.Pop();
            nodesProcessed++;

            // Visualize current node being processed
            if (current != startNode && current != endNode)
            {
                current.SetColor(gridManager.visitedMaterial.color);
            }

            if (current == endNode)
            {
                RetracePath(startNode, endNode, "DFS", visited.Count);
                isRunning = false;
                yield break;
            }

            // Get neighbors and reverse for proper DFS exploration
            List<Node> neighbors = new List<Node>(gridManager.GetNeighbors(current));
            neighbors.Reverse();

            foreach (Node neighbor in neighbors)
            {
                if (!visited.Contains(neighbor) && neighbor.walkable)
                {
                    visited.Add(neighbor);
                    neighbor.parent = current;
                    stack.Push(neighbor);

                    // Visualize discovery
                    if (neighbor != startNode && neighbor != endNode)
                    {
                        neighbor.SetColor(gridManager.discoveredMaterial.color);
                    }
                }
            }

            // Yield at meaningful milestones
            if (nodesProcessed % 2 == 0) // Yield every 2 nodes processed
            {
                yield return new WaitForSeconds(0.1f);
            }
        }

        Debug.Log("DFS: No path found!");
        isRunning = false;
    }

    IEnumerator RunAStar()
    {
        if (isRunning || isCapsuleMoving) yield break;
        isRunning = true;
        ResetCapsule();
        ResetNodeStates();

        algorithmStartTimes["A*"] = Time.time;
        if (pseudocodeDisplay != null)
            pseudocodeDisplay.ShowAlgorithmPseudocode("A*");

        Debug.Log("=== RUNNING A* ===");
        gridManager.ClearVisualization();

        Node startNode = gridManager.GetStartNode();
        Node endNode = gridManager.GetEndNode();

        PriorityQueue<Node> openSet = new PriorityQueue<Node>(); // CHANGED: Priority Queue
        HashSet<Node> closedSet = new HashSet<Node>();

        // Initialize all nodes
        foreach (Node node in gridManager.grid)
        {
            if (node != null)
            {
                node.gCost = int.MaxValue;
                node.hCost = GetDistance(node, endNode);
                node.parent = null;
            }
        }

        startNode.gCost = 0;
        openSet.Enqueue(startNode, startNode.fCost); // CHANGED: Enqueue with priority

        while (openSet.Count > 0)
        {
            Node current = openSet.Dequeue(); // CHANGED: Dequeue gives us lowest fCost automatically
            closedSet.Add(current);

            // Visualize current node being processed
            if (current != startNode && current != endNode)
            {
                current.SetColor(gridManager.visitedMaterial.color);
                yield return new WaitForSeconds(0.05f); // ADDED: Consistent timing
            }

            if (current == endNode)
            {
                RetracePath(startNode, endNode, "A*", closedSet.Count);
                isRunning = false;
                yield break;
            }

            foreach (Node neighbor in gridManager.GetNeighbors(current))
            {
                if (!neighbor.walkable || closedSet.Contains(neighbor))
                    continue;

                int newMovementCost = current.gCost + GetDistance(current, neighbor) * neighbor.weight;

                if (newMovementCost < neighbor.gCost || !openSet.Contains(neighbor))
                {
                    neighbor.gCost = newMovementCost;
                    neighbor.hCost = GetDistance(neighbor, endNode);
                    neighbor.parent = current;

                    if (!openSet.Contains(neighbor))
                    {
                        openSet.Enqueue(neighbor, neighbor.fCost); // CHANGED: Enqueue with fCost as priority

                        // Visualize discovered node
                        if (neighbor != startNode && neighbor != endNode)
                        {
                            neighbor.SetColor(gridManager.discoveredMaterial.color);
                            yield return new WaitForSeconds(0.05f);
                        }
                    }
                }
            }
        }

        Debug.Log("A*: No path found!");
        isRunning = false;
    }
    IEnumerator RunDijkstra()
    {
        if (isRunning || isCapsuleMoving) yield break;
        isRunning = true;
        ResetCapsule();
        ResetNodeStates();

        algorithmStartTimes["Dijkstra"] = Time.time;
        if (pseudocodeDisplay != null)
            pseudocodeDisplay.ShowAlgorithmPseudocode("Dijkstra");

        Debug.Log("=== RUNNING DIJKSTRA ===");
        gridManager.ClearVisualization();

        Node startNode = gridManager.GetStartNode();
        Node endNode = gridManager.GetEndNode();

        PriorityQueue<Node> openSet = new PriorityQueue<Node>(); // CHANGED: Priority Queue
        HashSet<Node> closedSet = new HashSet<Node>();

        // Initialize all nodes
        foreach (Node node in gridManager.grid)
        {
            if (node != null)
            {
                node.gCost = int.MaxValue;
                node.parent = null;
            }
        }

        startNode.gCost = 0;
        openSet.Enqueue(startNode, startNode.gCost); // CHANGED: Enqueue with gCost as priority

        while (openSet.Count > 0)
        {
            Node current = openSet.Dequeue(); // CHANGED: Dequeue gives us lowest gCost automatically
            closedSet.Add(current);

            // Visualize current node being processed
            if (current != startNode && current != endNode)
            {
                current.SetColor(gridManager.visitedMaterial.color);
                yield return new WaitForSeconds(0.05f); // ADDED: Consistent timing
            }

            if (current == endNode)
            {
                RetracePath(startNode, endNode, "Dijkstra", closedSet.Count);
                isRunning = false;
                yield break;
            }

            foreach (Node neighbor in gridManager.GetNeighbors(current))
            {
                if (!neighbor.walkable || closedSet.Contains(neighbor))
                    continue;

                int newCost = current.gCost + neighbor.weight;

                if (newCost < neighbor.gCost)
                {
                    neighbor.gCost = newCost;
                    neighbor.parent = current;

                    if (!openSet.Contains(neighbor))
                    {
                        openSet.Enqueue(neighbor, neighbor.gCost); // CHANGED: Enqueue with gCost as priority

                        // Visualize discovered nodes
                        if (neighbor != startNode && neighbor != endNode)
                        {
                            neighbor.SetColor(gridManager.discoveredMaterial.color);
                            yield return new WaitForSeconds(0.05f);
                        }
                    }
                }
            }
        }

        Debug.Log("Dijkstra: No path found!");
        isRunning = false;
    }

    private int GetDistance(Node nodeA, Node nodeB)
    {
        if (useManhattanHeuristic)
        {
            int dstX = Mathf.Abs(nodeA.x - nodeB.x);
            int dstY = Mathf.Abs(nodeA.y - nodeB.y);
            return dstX + dstY;
        }
        else
        {
            float dstX = nodeA.x - nodeB.x;
            float dstY = nodeA.y - nodeB.y;
            return Mathf.RoundToInt(Mathf.Sqrt(dstX * dstX + dstY * dstY));
        }
    }

    private void RetracePath(Node startNode, Node endNode, string algorithmName, int actualVisitedNodes)
    {
        List<Node> path = new List<Node>();
        Node currentNode = endNode;

        while (currentNode != startNode)
        {
            path.Add(currentNode);
            currentNode = currentNode.parent;
        }
        path.Reverse();

        int totalCost = 0;
        int highCostNodes = 0;

        foreach (Node node in path)
        {
            totalCost += node.weight;
            if (node.weight > 1) highCostNodes++; // FIX: Changed from == 10 to > 1
            if (node != endNode)
                node.SetColor(gridManager.pathMaterial.color);
        }

        // FIX: Use actual visited count passed from algorithm instead of broken gCost check
        int visitedNodes = actualVisitedNodes;

        float executionTime = 0f;
        if (algorithmStartTimes.ContainsKey(algorithmName))
        {
            executionTime = Time.time - algorithmStartTimes[algorithmName];
        }

        long memoryUsage = GetMemoryUsage(algorithmName, visitedNodes);
        int cpuOperations = CalculateCPUOperations(algorithmName, visitedNodes, path.Count);

        AlgorithmResult result = new AlgorithmResult
        {
            name = algorithmName,
            steps = path.Count,
            cost = totalCost,
            highCostNodes = highCostNodes,
            visitedNodes = visitedNodes,
            executionTime = executionTime,
            memoryUsage = memoryUsage,
            cpuOperations = cpuOperations
        };

        algorithmResults.Add(result);

        Debug.Log($"{algorithmName} RESULTS: {path.Count} steps, Cost: {totalCost}");
        Debug.Log($"High cost nodes: {highCostNodes}, Visited nodes: {visitedNodes}");
        Debug.Log($"Resource Usage: {memoryUsage} bytes memory, ~{cpuOperations} CPU operations");
        Debug.Log($"Execution Time: {executionTime:F2}s");

        UpdateResourceResultsDisplay();
        SpawnCapsule();
        StartCoroutine(MoveCapsuleAlongPath(path));
    }
}