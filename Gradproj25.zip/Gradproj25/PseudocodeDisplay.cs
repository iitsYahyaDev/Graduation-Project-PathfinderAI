using UnityEngine;
using TMPro;

public class PseudocodeDisplay : MonoBehaviour
{
    [Header("UI References")]
    public TextMeshProUGUI pseudocodeText;
    
    [Header("Pseudocode Content")]
    [TextArea(5, 15)]
    public string bfsPseudocode = 
        "BFS PSEUDOCODE:\n" +
        "1. Queue = [start]\n" +
        "2. Visited = {start}\n" +
        "3. WHILE queue not empty:\n" +
        "4.   current = queue.dequeue()\n" +
        "5.   IF current == goal: RETURN path\n" +
        "6.   FOR each neighbor of current:\n" +
        "7.     IF neighbor not visited AND walkable:\n" +
        "8.       visited.add(neighbor)\n" +
        "9.       queue.enqueue(neighbor)\n" +
        "KEY: Explores equally in all directions";
    
    [TextArea(5, 15)]
    public string dfsPseudocode = 
        "DFS PSEUDOCODE:\n" +
        "1. Stack = [start]\n" +
        "2. Visited = {start}\n" +
        "3. WHILE stack not empty:\n" +
        "4.   current = stack.pop()\n" +
        "5.   IF current == goal: RETURN path\n" +
        "6.   FOR each neighbor of current:\n" +
        "7.     IF neighbor not visited AND walkable:\n" +
        "8.       visited.add(neighbor)\n" +
        "9.       stack.push(neighbor)\n" +
        "KEY: Explores one path deeply first";
    
    [TextArea(5, 15)]
    public string aStarPseudocode = 
        "A* PSEUDOCODE:\n" +
        "1. OpenSet = [start], gScore[start] = 0\n" +
        "2. fScore[start] = h(start, goal)\n" +
        "3. WHILE openSet not empty:\n" +
        "4.   current = node with lowest fScore\n" +
        "5.   IF current == goal: RETURN path\n" +
        "6.   OpenSet.remove(current)\n" +
        "7.   FOR each neighbor of current:\n" +
        "8.     gTemp = gScore[current] + cost(neighbor)\n" +
        "9.     IF gTemp < gScore[neighbor]:\n" +
        "10.      Update scores and add to openSet\n" +
        "KEY: Uses heuristic + cost for efficiency";
    
    [TextArea(5, 15)]
    public string dijkstraPseudocode = 
        "DIJKSTRA PSEUDOCODE:\n" +
        "1. All nodes: distance = INFINITY\n" +
        "2. distance[start] = 0\n" +
        "3. Unvisited = all nodes\n" +
        "4. WHILE unvisited not empty:\n" +
        "5.   current = node with min distance\n" +
        "6.   IF current == goal: RETURN path\n" +
        "7.   Unvisited.remove(current)\n" +
        "8.   FOR each neighbor of current:\n" +
        "9.     alt = distance[current] + cost(neighbor)\n" +
        "10.    IF alt < distance[neighbor]:\n" +
        "11.      distance[neighbor] = alt\n" +
        "KEY: Finds absolute lowest cost path";

    public void ShowAlgorithmPseudocode(string algorithmName)
    {
        switch (algorithmName)
        {
            case "BFS":
                pseudocodeText.text = bfsPseudocode;
                break;
            case "DFS":
                pseudocodeText.text = dfsPseudocode;
                break;
            case "A*":
                pseudocodeText.text = aStarPseudocode;
                break;
            case "Dijkstra":
                pseudocodeText.text = dijkstraPseudocode;
                break;
            default:
                pseudocodeText.text = "Select an algorithm to see pseudocode";
                break;
        }
    }
    
    public void ClearPseudocode()
    {
        pseudocodeText.text = "Select an algorithm to see pseudocode";
    }
}
