﻿using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Diagnostics;

public class SaveManager : MonoBehaviour
{
    public Button savesButton;
    private string screenshotsRootPath;

    void Start()
    {
        screenshotsRootPath = Application.dataPath + "/Screenshots/";
        savesButton.onClick.AddListener(OpenScreenshotsFolder);
    }

    private void OpenScreenshotsFolder()
    {
        // Create folder if it doesn't exist
        if (!Directory.Exists(screenshotsRootPath))
        {
            Directory.CreateDirectory(screenshotsRootPath);
            UnityEngine.Debug.Log("Created Screenshots folder: " + screenshotsRootPath);
        }

        // Open the folder in file explorer
        try
        {
            Process.Start(screenshotsRootPath);
            UnityEngine.Debug.Log("Opened screenshots folder: " + screenshotsRootPath);
        }
        catch (System.Exception e)
        {
            UnityEngine.Debug.LogError("Failed to open folder: " + e.Message);

            // Fallback: Show the path in console so user can navigate manually
            UnityEngine.Debug.Log("Screenshots folder path: " + screenshotsRootPath);
            UnityEngine.Debug.Log("You can manually navigate to this folder in File Explorer");
        }
    }
}