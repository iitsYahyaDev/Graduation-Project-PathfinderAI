using UnityEngine;

public class Node : MonoBehaviour
{
    public int x, y;
    public bool walkable = true;
    public int weight = 1;
    public Node parent;
    
    public int gCost;
    public int hCost;
    public int fCost => gCost + hCost;
    
    private Renderer rend;
    
    public void Initialize(int x, int y, bool walkable, int weight = 1)
    {
        this.x = x;
        this.y = y;
        this.walkable = walkable;
        this.weight = weight;
        rend = GetComponent<Renderer>();
        UpdateColor();
    }
    
    public void SetWalkable(bool walkable)
    {
        this.walkable = walkable;
        UpdateColor();
    }
    
    public void SetWeight(int newWeight)
    {
        weight = newWeight;
        UpdateColor();
    }
    
    public void SetColor(Color color)
    {
        if (rend != null)
            rend.material.color = color;
    }
    
    private void UpdateColor()
    {
        if (!walkable)
            SetColor(GridManager.Instance.obstacleMaterial.color);
        else if (weight == 10)
            SetColor(GridManager.Instance.highCostMaterial.color);
        else
            SetColor(GridManager.Instance.walkableMaterial.color);
    }
    
    void OnMouseDown()
    {
        if (this != GridManager.Instance.GetStartNode() && this != GridManager.Instance.GetEndNode())
        {
            // Cycle through states: low cost -> high cost -> obstacle -> low cost
            if (walkable && weight == 1)
            {
                SetWeight(10); // High cost
            }
            else if (walkable && weight == 10)
            {
                SetWalkable(false); // Obstacle
            }
            else
            {
                SetWalkable(true); // Back to low cost
                SetWeight(1);
            }
        }
    }
}