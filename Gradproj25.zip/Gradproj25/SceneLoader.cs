using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SceneLoader : MonoBehaviour
{
    [Header("UI Settings")]
    public Button startButton; // Assign your start button in inspector

    [Header("Scene Settings")]
    public string gameSceneName = "Samplescene"; // Change this to your actual scene name

    void Start()
    {
        // Make sure the button is assigned and add click listener
        if (startButton != null)
        {
            startButton.onClick.AddListener(LoadGameScene);
        }
        else
        {
            Debug.LogError("Start button not assigned in SceneLoader!");
        }
    }

    public void LoadGameScene()
    {
        Debug.Log($"Loading scene: {gameSceneName}");

        // Load the game scene
        SceneManager.LoadScene(gameSceneName);
    }

    // Optional: Also allow keyboard input (Space/Enter)
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return))
        {
            LoadGameScene();
        }
    }
}